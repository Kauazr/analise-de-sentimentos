from tkinter import *

janela = Tk()
janela.title("Janela de Teste")
janela.geometry("300x200")
Label(janela, text="Tkinter está funcionando!").pack(pady=50)
janela.mainloop()
